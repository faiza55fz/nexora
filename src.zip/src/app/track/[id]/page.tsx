
import { DeliveryTip } from "@/components/delivery-tip";
import Link from "next/link";
import { Card } from "@/components/ui";
import { inr } from "@/lib/format";

type ApiOrderItem = {
  id: string;
  product_id: string;
  product_name: string;
  quantity: number;
  price: number;
};

type ApiOrder = {
  id: string;
  order_number: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string | null;
    delivery_partner_id: string | null;
  delivery_partner: {
    name: string;
    phone: string | null;
  } | null;
  address: string;
  subtotal: number;
  delivery_fee: number;
  total: number;
  payment_method: string;
  status: string;
  created_at: string;
  order_items: ApiOrderItem[];
};

const timeline = [
  { key: "placed", label: "Placed" },
  { key: "confirmed", label: "Confirmed" },
  { key: "packed", label: "Packed" },
  {
    key: "out-for-delivery",
    label: "Out for delivery",
  },
  { key: "delivered", label: "Delivered" },
];

function getStatusIndex(status: string) {
  const index = timeline.findIndex(
    (item) => item.key === status,
  );

  return Math.max(0, index);
}

function formatPaymentMethod(
  paymentMethod: string,
) {
  if (paymentMethod === "cod") {
    return "Cash on Delivery";
  }

  return paymentMethod;
}

export default async function TrackPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  let order: ApiOrder | null = null;

try {
  const { supabaseAdmin } = await import("@/lib/supabase-admin");

  const { data, error } = await supabaseAdmin
    .from("orders")
    .select(`
      id,
      order_number,
      customer_name,
      customer_email,
      customer_phone,
      delivery_partner_id,
      delivery_partner:delivery_partners (
        name,
        phone
      ),
      address,
      subtotal,
      delivery_fee,
      total,
      payment_method,
      status,
      created_at,
      order_items (
        id,
        product_id,
        product_name,
        quantity,
        price
      )
    `)
    .or(`id.eq.${id},order_number.eq.${id}`)
    .maybeSingle();

  if (error) {
    console.error(
      "Failed to load tracking order:",
      error,
    );
  } else {
    order = data as ApiOrder | null;
  }
} catch (error) {
  console.error(
    "Failed to load tracking order:",
    error,
  );
}
   

  if (!order) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-8">
        <Card className="p-6">
          <h1 className="text-xl font-semibold">
            Order not found
          </h1>

          <p className="mt-2 text-sm text-muted">
            We couldn't find this order.
            Please check the order number and
            try again.
          </p>
        </Card>
      </div>
    );
  }

  const isCancelled =
    order.status === "cancelled";

  const idx = getStatusIndex(
    order.status,
  );

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="text-2xl font-semibold">
        {isCancelled
          ? "Order cancelled"
          : "Track your order"}
      </h1>

      <p className="mt-1 text-sm text-muted">
        {formatPaymentMethod(
          order.payment_method,
        )}{" "}
        · {order.address}
      </p>
      {order.status === "out-for-delivery" &&
  order.delivery_partner && (
    <Card className="mt-4 p-5">
      <div className="flex items-center justify-between gap-4">
        <div>
          <p className="text-xs text-muted">
            Your delivery partner
          </p>

          <p className="mt-1 font-semibold">
            {order.delivery_partner.name}
          </p>

          {order.delivery_partner.phone && (
            <p className="mt-1 text-sm text-muted">
              {order.delivery_partner.phone}
            </p>
          )}
        </div>

        {order.delivery_partner.phone && (
          <a
            href={`tel:${order.delivery_partner.phone}`}
            className="rounded-xl bg-brand px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90"
          >
            Call
          </a>
        )}
      </div>
      <DeliveryTip orderId={order.id} />
    </Card>
  )}

      {isCancelled ? (
        <Card className="mt-6 p-6">
          <div className="flex items-start gap-3">
            <span className="mt-1 h-3 w-3 rounded-full bg-line" />

            <div>
              <p className="font-medium">
                Order cancelled
              </p>

              <p className="mt-1 text-sm text-muted">
                This order has been cancelled.
                
              </p>
            </div>
          </div>
        </Card>
      ) : (
        <Card className="mt-6 p-6">
          <ol className="space-y-4">
            {timeline.map((t, i) => (
              <li
                key={t.key}
                className="flex gap-3"
              >
                <span
                  className={`mt-1 h-3 w-3 rounded-full ${
                    i <= idx
                      ? "bg-success"
                      : "bg-line"
                  }`}
                />

                <div>
                  <p className="font-medium">
                    {t.label}
                  </p>

                  {i === idx ? (
                    <p className="text-sm text-muted">
                      Current status
                    </p>
                  ) : null}
                </div>
              </li>
            ))}
          </ol>
        </Card>
      )}

      <Card className="mt-4 p-6">
        <h2 className="font-semibold">
          Items
        </h2>

        <ul className="mt-3 space-y-2 text-sm">
          {order.order_items.map(
            (item) => (
              <li
                key={item.id}
                className="flex justify-between gap-4"
              >
                <span>
                  {item.product_name} ×{" "}
                  {item.quantity}
                </span>

                <span>
                  {inr(
                    Number(item.price) *
                      item.quantity,
                  )}
                </span>
              </li>
            ),
          )}
        </ul>

        <p className="mt-3 font-semibold">
          Total {inr(Number(order.total))}
        </p>
        {order.status === "delivered" ? (
  <div className="mt-5 flex flex-wrap gap-2">
    <Link
      href={`/reviews?orderId=${encodeURIComponent(order.id)}`}
      className="inline-flex items-center rounded-md border border-line px-4 py-2 text-sm font-medium hover:bg-muted"
    >
      Rate & Review
    </Link>

    <Link
      href={`/returns?orderId=${encodeURIComponent(order.id)}`}
      className="inline-flex items-center rounded-md border border-line px-4 py-2 text-sm font-medium hover:bg-muted"
    >
      Return & Refund
    </Link>
  </div>
) : null}
      </Card>
    </div>
  );
}